This directory contains information on uiports.
uiports are different graphics libraries using the same core
rdesktop files.

This directory is provided to include information and examples
on how to do a new uiport.  Not all ports of rdesktop can
be included.

see xxxreadme.txt for info on a blank empty uiport

see qtreadme.txt for info on the Qt/X11 uiport

see qtereadme.txt for info on the Qt embeded uiport

see svgareadme.txt for info on the svga uiport

see nanoxreadme.txt for info on the nanox uiport

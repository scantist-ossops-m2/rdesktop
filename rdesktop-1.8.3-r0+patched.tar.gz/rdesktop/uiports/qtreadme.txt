This is the Qt/X11 ui port
qt should be installed in /usr/local/qt
you may need to have LD_LIBRARY_PATH defined to run qtrdesktop
tested with versions 2.3.2, 3.1.2

makefile_qt can be edited to change file localtions
run make -f makefile_qt in this directory to compile it

qtreadme.txt - notes, this file
makefile_qt - makefile
qtwin.cpp - ui lib
qtwin.h - header
